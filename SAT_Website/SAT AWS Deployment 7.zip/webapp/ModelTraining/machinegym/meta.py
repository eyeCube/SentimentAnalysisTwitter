
# ranks
# how well does the word match the sentiment?

C_S=7
C_A=6
C_B=5
C_C=4
C_D=3
C_E=2
C_F=1

C__S = 1
C__A = 0.75
C__B = 0.5
C__C = 0.3333334
C__D = 0.25
C__E = 0.2
C__F = 0.1666667

C__RANKTOF={
C_F : C__F,
C_E : C__E,
C_D : C__D,
C_C : C__C,
C_B : C__B,
C_A : C__A,
C_S : C__S,
    }
