
PREFIX_QUALIFIERS={
# word          : (mult, adder,),
'very'          : (1,1,),
'majorly'       : (1,1,),
'extremely'     : (1,1,),
'super'         : (1,1,),
'uber'          : (1,1,),
'slightly'      : (1,-1,),
'barely'        : (1,-2,),
'not'           : (-1,0,),
"n't"           : (-1,0,),
    }

POSTFIX_QUALIFIERS={
'af'            : (1,1,),
'asf'           : (1,1,),
    }
